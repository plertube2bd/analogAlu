package com.example.analogalu.block;

import com.example.analogalu.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.phys.BlockHitResult;

public class CircuitDeviceBlock extends BaseEntityBlock {
    public enum Kind { BATTERY, SWITCH, RESISTOR }

    public static final EnumProperty<Direction> FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty CLOSED = BooleanProperty.create("closed");
    public static final double BATTERY_VOLTAGE = 9.0;
    public static final double BATTERY_INTERNAL_RESISTANCE = 0.15;
    public static final double LOAD_RESISTANCE = 10.0;
    public static final double BATTERY_CAPACITY_JOULES = 36_000.0;
    private final Kind kind;

    public CircuitDeviceBlock(BlockBehaviour.Properties properties, Kind kind) {
        super(properties);
        this.kind = kind;
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH).setValue(CLOSED, false));
    }

    public Kind kind() {
        return kind;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, CLOSED);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite())
                .setValue(CLOSED, false);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CircuitDeviceBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
            BlockEntityType<T> type) {
        return null;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState,
            boolean movedByPiston) {
        if (!level.isClientSide() && !oldState.is(this)) CircuitSolver.recomputeAround(level, pos);
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block,
            Orientation orientation, boolean movedByPiston) {
        if (!level.isClientSide()) CircuitSolver.recomputeAround(level, pos);
    }

    @Override
    protected void affectNeighborsAfterRemoval(BlockState state, ServerLevel level, BlockPos pos,
            boolean movedByPiston) {
        if (movedByPiston) return;
        CircuitSolver.recomputeAround(level, pos);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (!player.getAbilities().mayBuild) return InteractionResult.PASS;
        if (level.isClientSide()) return InteractionResult.SUCCESS;

        if (kind == Kind.SWITCH) {
            boolean closed = !state.getValue(CLOSED);
            level.setBlock(pos, state.setValue(CLOSED, closed), Block.UPDATE_ALL);
            level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 0.4F, closed ? 0.6F : 0.5F);
            CircuitSolver.recomputeAround(level, pos);
            player.sendSystemMessage(Component.literal(closed ? "Circuit switch: CLOSED" : "Circuit switch: OPEN"));
        } else if (kind == Kind.BATTERY) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            double joules = blockEntity instanceof CircuitDeviceBlockEntity battery
                    ? battery.getStoredEnergyJoules() : 0.0;
            Direction positive = state.getValue(FACING);
            player.sendSystemMessage(Component.literal(String.format(java.util.Locale.ROOT,
                "Battery: %.1f V | +%s / -%s | %.0f / %.0f J", BATTERY_VOLTAGE, positive.getName(),
                positive.getOpposite().getName(), joules, BATTERY_CAPACITY_JOULES)));
        } else {
            player.sendSystemMessage(Component.literal(String.format(java.util.Locale.ROOT,
                    "Resistive load: %.1f Ω", LOAD_RESISTANCE)));
        }
        return InteractionResult.SUCCESS;
    }
}