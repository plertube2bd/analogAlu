package com.example.analogalu.block;

import com.example.analogalu.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class CircuitDeviceBlockEntity extends BlockEntity {
    private double storedEnergyJoules = CircuitDeviceBlock.BATTERY_CAPACITY_JOULES;
    private long lastEnergyTick = -1L;

    public CircuitDeviceBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.CIRCUIT_DEVICE_ENTITY, pos, state);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        double stored = input.getDoubleOr("StoredEnergyJoules", CircuitDeviceBlock.BATTERY_CAPACITY_JOULES);
        storedEnergyJoules = Double.isFinite(stored)
            ? Math.clamp(stored, 0.0, CircuitDeviceBlock.BATTERY_CAPACITY_JOULES)
            : 0.0;
        lastEnergyTick = input.getLongOr("LastEnergyTick", -1L);
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putDouble("StoredEnergyJoules", storedEnergyJoules);
        output.putLong("LastEnergyTick", lastEnergyTick);
    }

    public double getStoredEnergyJoules() {
        return storedEnergyJoules;
    }

    public void consumeEnergy(double watts, long gameTime) {
        long elapsedTicks = lastEnergyTick < 0L ? 0L : Math.max(0L, gameTime - lastEnergyTick);
        lastEnergyTick = gameTime;
        if (Double.isFinite(watts) && watts > 0.0) {
            storedEnergyJoules = Math.max(0.0, storedEnergyJoules - watts * elapsedTicks / 20.0);
        }
        setChanged();
    }
}